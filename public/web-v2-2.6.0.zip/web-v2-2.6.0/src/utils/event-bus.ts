import mitt from 'mitt'

const bus = mitt()

export default bus;